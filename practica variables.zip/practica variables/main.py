# Atributes of a song

Name = 'Show Me Love'
Artist = 'Above & Beyond, Armin van Buuren and Sander van Doorn'
Writers = 'Armin van Buuren, Benno De Goeij, Jono Grant, Paavo Silijamaki, Tony McGuinness'
CuantityofProducers = 2
Media = 'Spotify'
Gender, Produceby, ReleaseDate = 'EDM', 'Armin van Buuren', '2021'
likes = 2348423.1
DurationofSong = '3:02 minutes'

print(Name)
print(Artist)
print(Writers)
print(CuantityofProducers)
print(Media)
print(Gender)
print(Produceby)
print(ReleaseDate)
print(likes)
print(DurationofSong)

