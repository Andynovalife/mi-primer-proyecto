#Homework

def GenreSong():
    Genre = 'EDM'
    print(Genre)
    return 

GenreSong()

def ArtistSong():
    Artist = 'Back in Time'
    print(Artist)
    return 

ArtistSong()

def YearSong():    
    Year = '2021'
    print(Year)
    return 

YearSong()

#EXTRACREDIT

def YearSong():
    return False

if YearSong():
    print('2021')
else:
    print('no hay fecha disponible')
    